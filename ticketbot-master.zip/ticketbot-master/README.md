# Ticket Bot
### Using Quick.db & Discord.js (V11)

#### DISCLAIMER: This does have errors, I will not be answering any issues.

##### This was another quick personal project of mine but never ended up fully finishing (cleaning up code, proper checks etc) and felt like this may help people.
##### A star is always appreciated
##### If you have an issue with Quick.db Or Discord.js Go to one of these links:

+ [Quick.db Repo](https://github.com/TrueXPixels/quick.db)
+ [Quick.db Discord](https://discordapp.com/invite/plexidev)
+ [Discord.js Discord](https://discordapp.com/invite/bRCvFy9)
